var searchData=
[
  ['xmax',['xmax',['../class_compute_boundary.html#a2c9f58bd66efd955555561b7d549af95',1,'ComputeBoundary']]],
  ['xmin',['xmin',['../class_compute_boundary.html#af46cac962e9b810cfe8d70e1c54f0eb8',1,'ComputeBoundary']]]
];
