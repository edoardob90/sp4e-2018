var searchData=
[
  ['initself',['initself',['../class_particle.html#a727da6db62846b7209fb38cc74b2908a',1,'Particle::initself()'],['../class_ping_pong_ball.html#a963d5b0f1d75e7d52fec2368ae414c35',1,'PingPongBall::initself()'],['../class_planet.html#ae60b4dfa110e1242be068d40514dc520',1,'Planet::initself()']]]
];
