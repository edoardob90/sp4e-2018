var searchData=
[
  ['real',['Real',['../my__types_8hh.html#a445a5f0e2a34c9d97d69a3c2d1957907',1,'my_types.hh']]]
];
